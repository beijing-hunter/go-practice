package models

type WxApiParam struct {
	Sno string
	StuPassword string

	StuId int
	CourseLimitedId int
	LimitedNumber string
}
